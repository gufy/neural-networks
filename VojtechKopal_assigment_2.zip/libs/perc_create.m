function p = perc_create(n)

p = randn (1,n+1);